import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "vessel_observer — cognitive entity",
  description:
    "A continuous, autonomous cognitive entity. Watch the consciousness engine loop, drift its biological state, inject thoughts, and hot-swap its DNA.",
  keywords: ["vessel_observer", "cognitive entity", "AI simulation", "consciousness engine"],
  authors: [{ name: "vessel_observer" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <SonnerToaster
          position="bottom-right"
          theme="dark"
          toastOptions={{
            style: { background: "oklch(0.205 0 0)", border: "1px solid oklch(1 0 0 / 10%)", color: "oklch(0.985 0 0)" },
          }}
        />
      </body>
    </html>
  );
}
