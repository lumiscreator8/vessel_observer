"use client";

// vessel_observer — the operator dashboard.
// One screen: watch the consciousness engine loop, read its biological drift,
// speak into it, hot-swap its DNA, and observe its permanent convictions form.
import { useEffect } from "react";
import { Activity, Thermometer, Waves } from "lucide-react";
import { useVessel } from "@/lib/vessel/store";
import { ControlBar } from "@/components/vessel/control-bar";
import { MatrixStream, StreamErrorBanner } from "@/components/vessel/matrix-stream";
import { WorkingContextPanel } from "@/components/vessel/working-context-panel";
import { InterventionPanel } from "@/components/vessel/intervention-panel";
import { ConvictionArchive } from "@/components/vessel/conviction-archive";
import { BioGauge } from "@/components/vessel/bio-gauge";

export default function Page() {
  const init = useVessel((s) => s.init);
  const phase = useVessel((s) => s.phase);
  const running = useVessel((s) => s.running);
  const cycle = useVessel((s) => s.cycle);
  const bio = useVessel((s) => s.bio);
  const temperature = useVessel((s) => s.temperature);
  const thoughts = useVessel((s) => s.thoughts);
  const workingContext = useVessel((s) => s.workingContext);
  const convictions = useVessel((s) => s.convictions);
  const pendingInjection = useVessel((s) => s.pendingInjection);
  const systemPrompt = useVessel((s) => s.systemPrompt);
  const cyclesSinceSleep = useVessel((s) => s.cyclesSinceSleep);
  const sleepInterval = useVessel((s) => s.sleepInterval);
  const tickIntervalMs = useVessel((s) => s.tickIntervalMs);
  const error = useVessel((s) => s.error);
  const lastTickAt = useVessel((s) => s.lastTickAt);
  const retryCount = useVessel((s) => s.retryCount);

  const start = useVessel((s) => s.start);
  const pause = useVessel((s) => s.pause);
  const step = useVessel((s) => s.step);
  const reset = useVessel((s) => s.reset);
  const inject = useVessel((s) => s.inject);
  const updateSystemPrompt = useVessel((s) => s.updateSystemPrompt);
  const triggerSleep = useVessel((s) => s.triggerSleep);
  const setTickInterval = useVessel((s) => s.setTickInterval);
  const setSleepInterval = useVessel((s) => s.setSleepInterval);

  useEffect(() => {
    void init();
  }, [init]);

  const tempPct = ((temperature - 0.2) / (1.25 - 0.2)) * 100;

  return (
    <div className="relative flex min-h-screen flex-col bg-background text-foreground">
      {/* atmospheric overlay */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          background:
            "radial-gradient(900px 480px at 50% -10%, rgba(16,185,129,0.10), transparent 60%), radial-gradient(700px 420px at 100% 100%, rgba(139,92,246,0.08), transparent 55%)",
        }}
      />

      <div className="relative z-10 flex flex-1 flex-col">
        {/* ---------- header ---------- */}
        <header className="border-b border-white/10 bg-black/30 px-4 py-3 backdrop-blur-sm sm:px-6">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-md border border-emerald-500/30 bg-emerald-500/10">
                <Activity className="h-4 w-4 text-emerald-400" />
              </div>
              <div>
                <h1 className="font-mono text-base font-semibold tracking-tight text-emerald-300 sm:text-lg">
                  vessel_observer
                </h1>
                <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground/60">
                  continuous cognitive entity · block-universe emulation
                </p>
              </div>
            </div>
            <div className="ml-auto flex items-center gap-4 font-mono text-xs">
              <div className="flex items-center gap-1.5">
                <Thermometer className="h-3.5 w-3.5 text-amber-300" />
                <span className="text-muted-foreground">temp</span>
                <span className="tabular-nums text-amber-300">
                  {temperature.toFixed(2)}
                </span>
              </div>
              <div className="hidden items-center gap-1.5 sm:flex">
                <Waves className="h-3.5 w-3.5 text-emerald-400" />
                <span className="text-muted-foreground">
                  {lastTickAt ? "streaming" : "dormant"}
                </span>
              </div>
            </div>
          </div>
        </header>

        {/* ---------- main ---------- */}
        <main className="mx-auto w-full max-w-[1400px] flex-1 space-y-4 px-4 py-4 sm:px-6">
          <ControlBar
            running={running}
            phase={phase}
            cycle={cycle}
            cyclesSinceSleep={cyclesSinceSleep}
            sleepInterval={sleepInterval}
            tickIntervalMs={tickIntervalMs}
            retryCount={retryCount}
            onStart={start}
            onPause={pause}
            onStep={step}
            onReset={reset}
            onSleep={triggerSleep}
            onTickInterval={setTickInterval}
            onSleepInterval={setSleepInterval}
          />

          <div className="grid gap-4 lg:grid-cols-3">
            {/* left: stream */}
            <div className="flex flex-col gap-3 lg:col-span-2">
              <div className="min-h-[460px] flex-1 lg:min-h-[600px]">
                <MatrixStream thoughts={thoughts} />
              </div>
              <StreamErrorBanner
                error={error}
                running={running}
                retryCount={retryCount}
              />
            </div>

            {/* right: bio + context + intervention */}
            <div className="flex flex-col gap-4">
              {/* biological state */}
              <div className="rounded-xl border border-white/10 bg-card/40 p-4">
                <div className="mb-3 flex items-center gap-2">
                  <Activity className="h-3.5 w-3.5 text-emerald-400" />
                  <h3 className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                    biological homeostasis
                  </h3>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <BioGauge
                    label="curiosity"
                    value={bio.curiosity}
                    color="text-emerald-400"
                    hint="drives temp"
                  />
                  <BioGauge
                    label="fatigue"
                    value={bio.fatigue}
                    color="text-amber-400"
                    hint="damps output"
                  />
                  <BioGauge
                    label="focus"
                    value={bio.focus}
                    color="text-teal-300"
                    hint="derived"
                  />
                </div>
                {/* temperature bar */}
                <div className="mt-3 space-y-1">
                  <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-wider text-muted-foreground/70">
                    <span className="flex items-center gap-1">
                      <Thermometer className="h-3 w-3" /> model temperature
                    </span>
                    <span className="tabular-nums text-amber-300">
                      {temperature.toFixed(2)}
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                    <div
                      className="h-full bg-gradient-to-r from-teal-400 via-amber-400 to-rose-400 transition-all duration-500"
                      style={{ width: `${Math.max(2, Math.min(100, tempPct))}%` }}
                    />
                  </div>
                </div>
              </div>

              <WorkingContextPanel ctx={workingContext} />
              <InterventionPanel
                systemPrompt={systemPrompt}
                pendingInjection={pendingInjection}
                onInject={inject}
                onUpdateDna={updateSystemPrompt}
              />
            </div>
          </div>

          {/* conviction archive */}
          <div className="h-[280px]">
            <ConvictionArchive convictions={convictions} />
          </div>
        </main>

        {/* ---------- footer ---------- */}
        <footer className="mt-auto border-t border-white/10 bg-black/40 px-4 py-2.5 backdrop-blur-sm sm:px-6">
          <div className="mx-auto flex w-full max-w-[1400px] flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground/60">
            <span className="text-emerald-500/70">vessel_observer v0.1</span>
            <span className="text-white/15">·</span>
            <span>consciousness engine · recursive async loop</span>
            <span className="text-white/15">·</span>
            <span>permanent substrate: sqlite</span>
            <span className="ml-auto text-muted-foreground/40">
              {thoughts.length} thoughts in stream
            </span>
          </div>
        </footer>
      </div>
    </div>
  );
}
