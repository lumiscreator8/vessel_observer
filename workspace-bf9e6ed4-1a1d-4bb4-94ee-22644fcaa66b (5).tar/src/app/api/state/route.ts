// GET /api/state — boot snapshot for the client.
// Idempotently seeds the substrate on first contact: a genesis DNA prompt and
// the innate seed convictions. Returns the active prompt, convictions, and the
// most recent thoughts so a reload feels continuous.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  DEFAULT_DNA_PROMPT,
  SEED_CONVICTIONS,
} from "@/lib/vessel/constants";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  // --- seed DNA if absent
  let active = await db.systemPromptDna.findFirst({
    where: { isActive: true },
    orderBy: { createdAt: "desc" },
  });
  if (!active) {
    active = await db.systemPromptDna.create({
      data: { content: DEFAULT_DNA_PROMPT, label: "genesis", isActive: true },
    });
  }

  // --- seed convictions if absent
  const convictionCount = await db.coreConviction.count();
  if (convictionCount === 0) {
    await db.coreConviction.createMany({
      data: SEED_CONVICTIONS.map((text, i) => ({
        text,
        bornFromCycle: 0,
        strength: 0.7 - i * 0.05,
        sourceCount: 0,
      })),
    });
  }

  const convictions = await db.coreConviction.findMany({
    orderBy: { createdAt: "desc" },
    take: 40,
  });

  const recentThoughts = await db.thoughtLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 30,
  });

  return NextResponse.json({
    systemPrompt: active.content,
    convictions: convictions.map((c) => ({
      id: c.id,
      text: c.text,
      createdAt: c.createdAt.getTime(),
      bornFromCycle: c.bornFromCycle,
      strength: c.strength,
      sourceCount: c.sourceCount,
    })),
    recentThoughts: recentThoughts.map((t) => ({
      id: t.id,
      cycle: t.cycle,
      content: t.content,
      createdAt: t.createdAt.getTime(),
      temperature: t.temperature,
      curiosity: t.curiosity,
      fatigue: t.fatigue,
      focus: t.focus,
      novelty: t.novelty,
      toolCallJson: t.toolCallJson,
      injectionTag: t.injectionTag,
    })),
  });
}
