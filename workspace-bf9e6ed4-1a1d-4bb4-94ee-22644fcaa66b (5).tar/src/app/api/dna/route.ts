// POST /api/dna — hot-swap the System Prompt DNA.
// Deactivates the previous active prompt and writes a new active version,
// preserving history. This is the Intervention Layer's DNA editor endpoint.
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const content = String(body?.content ?? "").trim();
  if (!content) {
    return NextResponse.json({ error: "empty dna" }, { status: 400 });
  }
  await db.$transaction([
    db.systemPromptDna.updateMany({
      data: { isActive: false },
      where: { isActive: true },
    }),
    db.systemPromptDna.create({
      data: { content, label: `hot-swap ${Date.now()}`, isActive: true },
    }),
  ]);
  return NextResponse.json({ ok: true });
}

export async function GET() {
  const versions = await db.systemPromptDna.findMany({
    orderBy: { createdAt: "desc" },
    take: 10,
  });
  return NextResponse.json({ versions });
}
