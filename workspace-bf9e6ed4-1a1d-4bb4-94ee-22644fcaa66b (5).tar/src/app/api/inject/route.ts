// POST /api/inject — persist an operator injection ("the voice").
// Stored for replay/audit; the client also holds it in working memory.
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { InjectRequest } from "@/lib/vessel/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  let body: InjectRequest;
  try {
    body = (await req.json()) as InjectRequest;
  } catch {
    return NextResponse.json({ error: "invalid json" }, { status: 400 });
  }
  const text = String(body.text ?? "").trim();
  if (!text) {
    return NextResponse.json({ error: "empty injection" }, { status: 400 });
  }
  const created = await db.injectionMessage.create({
    data: { text, consumed: false },
  });
  return NextResponse.json({ ok: true, id: created.id });
}
