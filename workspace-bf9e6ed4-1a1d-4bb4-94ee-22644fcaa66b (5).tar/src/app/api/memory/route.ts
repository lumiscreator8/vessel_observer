// /api/memory — dual-purpose permanent substrate endpoint.
//  * GET  /api/memory         → health probe
//  * POST /api/memory?op=log  → append a thought to ThoughtLog
//  * POST /api/memory (default) → retrieve top-K semantic injections
//     (lexical retrieval over convictions + recent thoughts; stand-in for
//      true vector search — see src/lib/vessel/retrieval.ts)
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { retrieve, type Candidate } from "@/lib/vessel/retrieval";
import type { MemoryQueryRequest } from "@/lib/vessel/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const count = await db.thoughtLog.count();
  return NextResponse.json({ ok: true, thoughtsLogged: count });
}

export async function POST(req: NextRequest) {
  const op = req.nextUrl.searchParams.get("op");

  // ------------------------------------------------ append a thought
  if (op === "log") {
    const body = await req.json();
    try {
      await db.thoughtLog.create({
        data: {
          cycle: Number(body.cycle ?? 0),
          content: String(body.content ?? ""),
          temperature: Number(body.temperature ?? 0.7),
          curiosity: Number(body.curiosity ?? 0),
          fatigue: Number(body.fatigue ?? 0),
          focus: Number(body.focus ?? 0),
          novelty: Number(body.novelty ?? 0),
          toolCallJson: body.toolCallJson ? String(body.toolCallJson) : null,
          injectionTag: body.injectionTag ? String(body.injectionTag) : null,
        },
      });
      return NextResponse.json({ ok: true });
    } catch (e) {
      return NextResponse.json(
        { error: `log failed: ${(e as Error).message}` },
        { status: 500 }
      );
    }
  }

  // ------------------------------------------------ retrieve injections
  let body: MemoryQueryRequest;
  try {
    body = (await req.json()) as MemoryQueryRequest;
  } catch {
    return NextResponse.json({ error: "invalid json" }, { status: 400 });
  }

  const seed = String(body.seed ?? "");
  const topK = Math.min(Math.max(Number(body.topK ?? 3), 1), 6);

  const [convictions, recentThoughts] = await Promise.all([
    db.coreConviction.findMany({
      orderBy: { createdAt: "desc" },
      take: 30,
    }),
    db.thoughtLog.findMany({
      orderBy: { createdAt: "desc" },
      take: 20,
    }),
  ]);

  const candidates: Candidate[] = [
    ...convictions.map((c) => ({
      id: c.id,
      text: c.text,
      source: "conviction" as const,
    })),
    ...recentThoughts
      .filter((t) => !seed.includes(t.content.slice(0, 20)))
      .map((t) => ({
        id: t.id,
        text: t.content,
        source: "thought" as const,
      })),
  ];

  const injections = retrieve(seed, candidates, topK);
  return NextResponse.json({ injections });
}
