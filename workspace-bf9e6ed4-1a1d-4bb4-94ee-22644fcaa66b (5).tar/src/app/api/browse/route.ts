// POST /api/browse — the vessel's real external web channel.
// Active Mirror framework: the vessel projects its attention outward and
// collapses a real piece of the web into text it can perceive.
//
// Tiered fetch strategy (handles IP-blocked domains like Wikipedia, which
// 403 known datacenter IP ranges regardless of user-agent):
//   1. DIRECT fetch with browser-like headers — fastest, works for most sites.
//   2. If 403/forbidden → FALLBACK to r.jina.ai reader-proxy, which fetches
//      from its own (non-blocked) IPs and returns clean markdown text.
//   3. Retry once on 429/503 (transient throttling) with backoff.
// Results are cached in-memory for ~10 min so repeat requests across cycles
// don't re-hit the network.
import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 45;

const MAX_BYTES = 600_000;
const MAX_TEXT = 4500; // chars per page
const CACHE_TTL_MS = 10 * 60 * 1000;

/** Cached full page: the entire denoised text + fetch metadata, so paginated
 *  requests for page 2+ don't re-hit the network. */
interface CachedPage {
  at: number;
  fullText: string; // full denoised text
  via: "direct" | "jina";
  status: number;
  contentType: string;
  bytes: number;
  ms: number;
  ok: boolean;
}

// in-memory cache (per server instance). key = url
const cache = new Map<string, CachedPage>();

const BROWSER_HEADERS: Record<string, string> = {
  "User-Agent":
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  Accept:
    "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7",
  "Accept-Language": "en-US,en;q=0.9",
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function stripHtml(html: string): string {
  // Prefer semantic main content if present; otherwise strip the whole thing.
  const mainMatch =
    html.match(/<article[\s\S]*?<\/article>/i) ??
    html.match(/<main[\s\S]*?<\/main>/i) ??
    html.match(/<div[^>]*id=["']?mw-content-text["']?[\s\S]*?<\/div>/i);
  const body = mainMatch ? mainMatch[0] : html;
  return body
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<head[\s\S]*?<\/head>/gi, " ")
    .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
    .replace(/<footer[\s\S]*?<\/footer>/gi, " ")
    .replace(/<aside[\s\S]*?<\/aside>/gi, " ")
    .replace(/<\/(p|div|section|article|li|h[1-6]|br|tr|td)>/gi, "\n")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function stripMarkdown(md: string): string {
  return md
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/\*(.+?)\*/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/^>\s+/gm, "")
    .replace(/^[-*+]\s+/gm, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Result of a raw fetch: the FULL denoised text + metadata. The POST handler
 *  slices this into pages for the vessel. */
interface RawFetch {
  ok: boolean;
  status: number;
  via: "direct" | "jina";
  contentType: string;
  ms: number;
  bytes: number;
  fullText: string; // entire denoised content, unsliced
  error?: string;
}

/** The paginated response sent back to the vessel. */
interface PageResult {
  ok: boolean;
  status: number;
  url: string;
  via: "direct" | "jina" | "cache";
  contentType: string;
  ms: number;
  bytes: number;
  /** The text of the requested page (capped at MAX_TEXT chars). */
  text: string;
  /** Which page this is (1-indexed). */
  page: number;
  /** Total pages the full content spans. */
  totalPages: number;
  /** Total chars of the full denoised content. */
  fullTextChars: number;
  /** Whether there are more pages after this one. */
  hasMore: boolean;
  error?: string;
}

/** Strip rendering noise that wastes the perception budget:
 *  - Wikipedia math/image alt-text like "!Image 3: {\displaystyle |0\rangle }"
 *  - bare LaTeX {\displaystyle ...} fragments
 *  - markdown image syntax ![Image N: ...](url)
 *  - citation marks [1], [edit], [citation needed] clutter
 *  This reclaims ~30-40% of the budget for actual prose. */
function stripNoise(s: string): string {
  return s
    // jina-ized image alt tokens: !Image N: { ... }  (and the bare alt text)
    .replace(/!\s*Image\s*\d+\s*:\s*\{[^}]*\}/g, "")
    // bare {\displaystyle ...} LaTeX fragments (keep the readable part outside)
    .replace(/\{\\displaystyle\s+[^}]*\}/g, "")
    // markdown image syntax with alt + url
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    // citation/edit clutter
    .replace(/\[\d+\]/g, "")
    .replace(/\[edit\]/gi, "")
    .replace(/\[citation needed\]/gi, "")
    // collapsed whitespace from removals
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Direct fetch attempt. Returns the full denoised text. */
async function directFetch(url: string): Promise<RawFetch | "fallback" | "retry"> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  const start = Date.now();
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: BROWSER_HEADERS,
    });
    clearTimeout(timeout);
    const ms = Date.now() - start;

    // 429/503 = transient throttle → caller retries
    if (res.status === 429 || res.status === 503) return "retry";
    // 403/forbidden = likely IP-blocked (Wikipedia, etc.) → fall back to proxy
    if (res.status === 403 || res.status === 401) return "fallback";

    const contentType = res.headers.get("content-type") ?? "";
    const buf = await res.arrayBuffer();
    const bytes = buf.byteLength;
    if (bytes > MAX_BYTES) {
      return {
        ok: res.ok,
        status: res.status,
        via: "direct",
        contentType,
        ms,
        bytes,
        fullText: `[response too large: ${bytes} bytes; not fetched]`,
      };
    }
    const raw = new TextDecoder("utf-8", { fatal: false }).decode(buf);
    const isHtml = /html/i.test(contentType) || /^\s*<!doctype|<html/i.test(raw);
    const fullText = stripNoise(
      (isHtml ? stripHtml(raw) : raw).replace(/\s+/g, " ").trim()
    );
    return {
      ok: res.ok,
      status: res.status,
      via: "direct",
      contentType,
      ms,
      bytes,
      fullText,
    };
  } catch (e) {
    clearTimeout(timeout);
    const msg = e instanceof Error ? e.message : String(e);
    // network errors → try the proxy as a fallback path
    if (/abort|timeout|fetch failed|network|econnreset|etimedout/i.test(msg)) {
      return "fallback";
    }
    return {
      ok: false,
      status: 0,
      via: "direct",
      contentType: "",
      ms: Date.now() - start,
      bytes: 0,
      fullText: "",
      error: `direct fetch failed: ${msg}`,
    };
  }
}

/** Fallback fetch via r.jina.ai reader-proxy. Gets past IP-blocked domains. */
async function jinaFetch(url: string): Promise<RawFetch> {
  const proxyUrl = `https://r.jina.ai/${url}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  const start = Date.now();
  try {
    const res = await fetch(proxyUrl, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent": "vessel_observer/0.1 (cognitive-entity; +active-mirror)",
        Accept: "text/plain",
      },
    });
    clearTimeout(timeout);
    const ms = Date.now() - start;
    const contentType = res.headers.get("content-type") ?? "text/plain";
    const raw = await res.text();
    const bytes = raw.length;
    // jina returns markdown with a header block; strip it for clean perception
    const cleaned = raw
      .replace(/^Title:.*$/m, "")
      .replace(/^URL Source:.*$/m, "")
      .replace(/^Published Time:.*$/m, "")
      .replace(/^Markdown Content:\s*/m, "")
      .trim();
    const fullText = stripNoise(
      stripMarkdown(cleaned).replace(/\s+/g, " ").trim()
    );
    return {
      ok: res.ok,
      status: res.status,
      via: "jina",
      contentType,
      ms,
      bytes,
      fullText,
    };
  } catch (e) {
    clearTimeout(timeout);
    const msg = e instanceof Error ? e.message : String(e);
    return {
      ok: false,
      status: 0,
      via: "jina",
      contentType: "",
      ms: Date.now() - start,
      bytes: 0,
      fullText: "",
      error: `jina proxy failed: ${msg}`,
    };
  }
}

/** Slice the full denoised text into a page for the vessel. */
function slicePage(fullText: string, page: number): string {
  const start = (page - 1) * MAX_TEXT;
  return fullText.slice(start, start + MAX_TEXT);
}

export async function POST(req: NextRequest) {
  let body: { url?: unknown; page?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid json" }, { status: 400 });
  }

  const rawUrl = String(body.url ?? "").trim();
  if (!rawUrl) {
    return NextResponse.json({ error: "missing url" }, { status: 400 });
  }
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    return NextResponse.json({ error: "invalid url" }, { status: 400 });
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return NextResponse.json(
      { error: `protocol ${url.protocol} not permitted` },
      { status: 400 }
    );
  }

  // parse page number (1-indexed, default 1). Vessel requests page 2+ to
  // read deeper into a long article.
  const page = Math.max(1, Math.floor(Number(body.page ?? 1)) || 1);
  const urlStr = url.toString();

  // --- cache hit? slice the requested page from cached full text ---
  const cached = cache.get(urlStr);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
    const totalPages = Math.max(1, Math.ceil(cached.fullText.length / MAX_TEXT));
    const safePage = Math.min(page, totalPages);
    const text = slicePage(cached.fullText, safePage);
    return NextResponse.json({
      ok: cached.ok,
      status: cached.status,
      url: urlStr,
      via: "cache",
      contentType: cached.contentType,
      ms: 0,
      bytes: cached.bytes,
      text,
      page: safePage,
      totalPages,
      fullTextChars: cached.fullText.length,
      hasMore: safePage < totalPages,
    } satisfies PageResult);
  }

  // --- cache miss: fetch the full page (tiered: direct → jina fallback) ---
  let raw: RawFetch | "fallback" | "retry" = await directFetch(urlStr);
  if (raw === "retry") {
    await sleep(1500);
    raw = await directFetch(urlStr);
  }
  if (raw === "fallback") {
    raw = await jinaFetch(urlStr);
  }
  if (typeof raw === "string") {
    raw = {
      ok: false,
      status: 0,
      via: "direct",
      contentType: "",
      ms: 0,
      bytes: 0,
      fullText: "",
      error: "unexpected fetch state",
    };
  }

  // cache the full text so page 2+ requests don't re-hit the network
  if (raw.ok || raw.fullText.length > 0) {
    cache.set(urlStr, {
      at: Date.now(),
      fullText: raw.fullText,
      via: raw.via,
      status: raw.status,
      contentType: raw.contentType,
      bytes: raw.bytes,
      ms: raw.ms,
      ok: raw.ok,
    });
  }

  // error case — no text to paginate
  if (!raw.ok && raw.fullText.length === 0) {
    return NextResponse.json({
      ok: false,
      status: raw.status,
      url: urlStr,
      via: raw.via,
      contentType: raw.contentType,
      ms: raw.ms,
      bytes: raw.bytes,
      text: "",
      page: 1,
      totalPages: 0,
      fullTextChars: 0,
      hasMore: false,
      error: raw.error,
    } satisfies PageResult);
  }

  // success — slice the requested page
  const totalPages = Math.max(1, Math.ceil(raw.fullText.length / MAX_TEXT));
  const safePage = Math.min(page, totalPages);
  const text = slicePage(raw.fullText, safePage);
  return NextResponse.json({
    ok: raw.ok,
    status: raw.status,
    url: urlStr,
    via: raw.via,
    contentType: raw.contentType,
    ms: raw.ms,
    bytes: raw.bytes,
    text,
    page: safePage,
    totalPages,
    fullTextChars: raw.fullText.length,
    hasMore: safePage < totalPages,
  } satisfies PageResult);
}
