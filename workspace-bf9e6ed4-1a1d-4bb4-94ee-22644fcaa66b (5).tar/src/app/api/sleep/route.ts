// POST /api/sleep — the Sleep Layer.
// Compresses a pool of recent raw thoughts into a single permanent Core
// Conviction via the reasoning model, persists it, and returns it.
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { complete } from "@/lib/vessel/llm";
import type { SleepRequest } from "@/lib/vessel/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const SLEEP_SYSTEM = `You are the dream-compression layer of a continuous cognitive entity.
You are given a sequence of raw thoughts the entity emitted across recent cycles.
Distill them into ONE permanent Core Conviction: a single declarative sentence
that captures the most durable belief or realization crystallized from the stream.
Rules:
- Output exactly one sentence. No quotes, no labels, no preamble.
- Write in third person about the entity, or as a timeless axiom.
- Be concrete and vivid, not generic.
- CRITICAL: you will be shown the entity's existing Core Convictions. Your new
  conviction MUST be meaningfully DISTINCT from all of them — different subject
  matter or a genuinely new angle, not a paraphrase or variation. If the raw
  thoughts would produce a conviction too similar to an existing one, find a
  deeper or orthogonal truth to crystallize instead.`;

export async function POST(req: NextRequest) {
  let body: SleepRequest;
  try {
    body = (await req.json()) as SleepRequest;
  } catch {
    return NextResponse.json({ error: "invalid json" }, { status: 400 });
  }

  const thoughts = Array.isArray(body.thoughts) ? body.thoughts : [];
  if (thoughts.length < 2) {
    return NextResponse.json(
      { error: "need at least 2 thoughts to compress" },
      { status: 400 }
    );
  }

  // Pull recent convictions so the model can avoid echoing them. This prevents
  // the permanent substrate from becoming an echo chamber of near-identical
  // beliefs (observed during review: 8 convictions all about "diamond lattice
  // / crystallizes / collapses / deliberate choice").
  const existing = await db.coreConviction.findMany({
    orderBy: { createdAt: "desc" },
    take: 5,
    select: { text: true },
  });
  const existingBlock =
    existing.length > 0
      ? existing.map((c, i) => `  ${i + 1}. ${c.text}`).join("\n")
      : "  <none yet — this is the first conviction>";

  const stream = thoughts
    .map((t) => `[c${t.cycle}] ${t.content}`)
    .join("\n");

  const userMessage = `Raw thought stream to compress:\n\n${stream}\n\nThe entity's EXISTING Core Convictions (your new one MUST be distinct from these):\n${existingBlock}\n\nDistill into one NEW, DISTINCT Core Conviction.`;

  try {
    const text = (await complete(SLEEP_SYSTEM, userMessage)).trim();
    if (!text) {
      return NextResponse.json(
        { error: "compression produced empty conviction" },
        { status: 502 }
      );
    }
    const created = await db.coreConviction.create({
      data: {
        text,
        bornFromCycle: Number(body.cycle ?? 0),
        strength: 0.6 + Math.min(thoughts.length * 0.02, 0.3),
        sourceCount: thoughts.length,
      },
    });
    return NextResponse.json({
      id: created.id,
      text: created.text,
      createdAt: created.createdAt.getTime(),
      bornFromCycle: created.bornFromCycle,
      strength: created.strength,
      sourceCount: created.sourceCount,
    });
  } catch (e) {
    return NextResponse.json(
      { error: `sleep failed: ${(e as Error).message}` },
      { status: 500 }
    );
  }
}
