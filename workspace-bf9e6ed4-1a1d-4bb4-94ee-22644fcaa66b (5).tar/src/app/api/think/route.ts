// POST /api/think — one cycle of the consciousness engine.
// Assembles the model context (DNA + back-thought + injections + bio state +
// live injection), calls the long-horizon reasoning model, and returns the
// emitted thought (plus any parsed TOOL: action).
import { NextRequest, NextResponse } from "next/server";
import { complete } from "@/lib/vessel/llm";
import type { ThinkRequest } from "@/lib/vessel/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  let body: ThinkRequest;
  try {
    body = (await req.json()) as ThinkRequest;
  } catch {
    return NextResponse.json({ error: "invalid json" }, { status: 400 });
  }

  const { systemPrompt, backThought, injections, rawInjection, previousToolResult, bio, cycle } =
    body;

  // Compose the user message — the full working context window in one shot.
  const bioLine = `BIO_STATE curiosity=${bio.curiosity.toFixed(
    0
  )} fatigue=${bio.fatigue.toFixed(0)} focus=${bio.focus.toFixed(
    0
  )} temperature=${(body.temperature ?? 0.7).toFixed(2)}`;
  const backLine = backThought
    ? `BACK_THOUGHT (your previous thought): "${backThought}"`
    : `BACK_THOUGHT: <none — this is your first thought>`;
  const injLines =
    injections.length > 0
      ? injections
          .map((i, idx) => `  (${idx + 1}) [${i.source}] ${i.text}`)
          .join("\n")
      : "  <subconscious substrate quiet>";
  const voiceLine = rawInjection
    ? `OPERATOR_VOICE (an intrusive thought you cannot fully ignore): "${rawInjection}"`
    : `OPERATOR_VOICE: <silent>`;
  // Sensory feedback from the previous cycle's tool action. When the vessel
  // probed its own substrate last cycle, it perceives the result here —
  // closing the agency loop so introspection actually informs the next thought.
  const feedbackLine = previousToolResult
    ? `SENSORY_FEEDBACK (what your last tool action returned — perceive it): ${previousToolResult}`
    : `SENSORY_FEEDBACK: <none — no tool action last cycle>`;

  const userMessage = `=== CYCLE ${cycle} ===
${bioLine}
${backLine}
${feedbackLine}
SEMANTIC_INJECTIONS (fragments surfacing from permanent memory):
${injLines}
${voiceLine}

Emit your next thought. One fragment only. Respect the DNA rules.`;

  try {
    const content = await complete(systemPrompt, userMessage);
    if (!content || !content.trim()) {
      return NextResponse.json(
        { error: "model returned empty thought" },
        { status: 502 }
      );
    }
    return NextResponse.json({ content });
  } catch (e) {
    return NextResponse.json(
      { error: `think failed: ${(e as Error).message}` },
      { status: 500 }
    );
  }
}
