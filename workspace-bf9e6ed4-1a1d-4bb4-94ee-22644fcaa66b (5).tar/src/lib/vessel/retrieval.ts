// vessel_observer — lexical "semantic" retrieval over the permanent substrate.
// A stand-in for true embedding search: deterministic, free, and good enough
// for a browser simulation. Scores candidates by token-overlap (Jaccard)
// against the seed, returns the top-K.

const STOP = new Set([
  "the","and","that","this","with","from","have","your","you","are","was","were",
  "but","not","for","all","can","will","its","it","is","as","at","be","by","on",
  "or","an","of","to","in","a","i","am","my","me","we","they","them","their",
  "what","which","who","when","how","why","where","into","out","up","down","over",
  "about","than","then","so","if","no","yes","do","does","did","been","being",
]);

function tokenize(s: string): Set<string> {
  return new Set(
    s
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 2 && !STOP.has(w))
  );
}

function jaccard(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 || b.size === 0) return 0;
  let inter = 0;
  for (const w of a) if (b.has(w)) inter++;
  const union = a.size + b.size - inter;
  return union === 0 ? 0 : inter / union;
}

export interface Candidate {
  id: string;
  text: string;
  source: "conviction" | "thought" | "injection";
}

/** Return the top-K candidates most lexically similar to the seed. */
export function retrieve(
  seed: string,
  candidates: Candidate[],
  topK: number
): { id: string; text: string; source: string; score: number }[] {
  const seedTokens = tokenize(seed);
  const scored = candidates.map((c) => ({
    id: c.id,
    text: c.text,
    source: c.source,
    score: jaccard(seedTokens, tokenize(c.text)),
  }));
  scored.sort((a, b) => b.score - a.score);
  // Always return up to topK; if scores are 0, still inject something so the
  // window isn't empty (simulates ambient subconscious leakage).
  const top = scored.slice(0, topK);
  const maxScore = top[0]?.score ?? 0;
  return top.map((t) => ({
    ...t,
    score: maxScore > 0 ? t.score / maxScore : 0.33,
  }));
}
