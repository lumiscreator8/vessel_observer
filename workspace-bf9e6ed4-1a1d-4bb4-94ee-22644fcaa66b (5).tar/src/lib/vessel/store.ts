"use client";

// vessel_observer — the Consciousness Engine.
// A recursive-async tick loop living in a Zustand store. It breathes via
// setTimeout between cycles so the browser thread is never blocked, and it
// delegates all heavy reasoning + durable memory to server API routes.

import { create } from "zustand";
import type {
  BiologicalState,
  CoreConviction,
  LoopPhase,
  SemanticInjection,
  ThinkRequest,
  ThinkResponse,
  Thought,
  ToolCall,
  VesselState,
} from "./types";
import {
  DEFAULT_DNA_PROMPT,
  DEFAULT_SLEEP_INTERVAL,
  DEFAULT_TICK_INTERVAL_MS,
  MAX_TRANSIENT_RETRIES,
  SEED_CONVICTIONS,
  STREAM_MAX,
  STUCK_NOVELTY,
  backoffDelay,
  bioToTemperature,
  clamp,
  computeIntrospection,
  computeNovelty,
  digestPrompt,
  driftBio,
  escapeSpike,
  isTransientError,
  jitter,
  uid,
} from "./constants";

interface VesselStore extends VesselState {
  // lifecycle
  init: () => Promise<void>;
  start: () => void;
  pause: () => void;
  step: () => Promise<void>;
  reset: () => void;
  // operator intervention
  inject: (text: string) => Promise<void>;
  updateSystemPrompt: (content: string) => Promise<void>;
  triggerSleep: () => Promise<void>;
  // tuning
  setTickInterval: (ms: number) => void;
  setSleepInterval: (n: number) => void;
  clearStream: () => void;
}

// Non-reactive handles kept outside the store so the loop can reschedule itself
// without subscribing to React renders.
let tickHandle: ReturnType<typeof setTimeout> | null = null;
let inFlight = false;

const INITIAL_BIO: BiologicalState = { curiosity: 72, fatigue: 12, focus: 86 };

export const useVessel = create<VesselStore>((set, get) => ({
  phase: "idle",
  running: false,
  cycle: 0,
  bio: INITIAL_BIO,
  temperature: bioToTemperature(INITIAL_BIO),
  thoughts: [],
  workingContext: {
    systemPromptDigest: digestPrompt(DEFAULT_DNA_PROMPT),
    backThought: null,
    injections: [],
    rawInjection: null,
    previousToolResult: null,
  },
  convictions: [],
  pendingInjection: null,
  systemPrompt: DEFAULT_DNA_PROMPT,
  cyclesSinceSleep: 0,
  sleepInterval: DEFAULT_SLEEP_INTERVAL,
  tickIntervalMs: DEFAULT_TICK_INTERVAL_MS,
  error: null,
  lastTickAt: null,
  retryCount: 0,
  consecutiveLowNovelty: 0,

  // ---------------------------------------------------------------- init
  init: async () => {
    try {
      const res = await fetch("/api/state");
      const data = await res.json();
      const systemPrompt: string = data.systemPrompt ?? DEFAULT_DNA_PROMPT;
      const convictions: CoreConviction[] = data.convictions ?? [];
      const recent: Thought[] = (data.recentThoughts ?? []).map(
        (t: Record<string, unknown>) => ({
          id: String(t.id),
          cycle: Number(t.cycle),
          phase: "idle",
          content: String(t.content),
          timestamp: Number(t.createdAt ?? Date.now()),
          bio: {
            curiosity: Number(t.curiosity),
            fatigue: Number(t.fatigue),
            focus: Number(t.focus),
          },
          temperature: Number(t.temperature),
          novelty: Number(t.novelty),
          toolCall: t.toolCallJson ? parseToolCall(t.toolCallJson) : undefined,
          injectionTag: t.injectionTag ? String(t.injectionTag) : undefined,
        })
      );
      const cycle = recent.length ? recent[0].cycle + 1 : 0;
      set({
        systemPrompt,
        convictions,
        thoughts: recent,
        cycle,
        workingContext: {
          ...get().workingContext,
          systemPromptDigest: digestPrompt(systemPrompt),
          backThought: recent[0] ?? null,
        },
      });
    } catch (e) {
      // Non-fatal: fall back to defaults so the loop can still run.
      set({ error: `init failed: ${(e as Error).message}` });
    }
  },

  // ---------------------------------------------------------------- start
  start: () => {
    if (get().running) return;
    set({ running: true, phase: "idle", error: null, retryCount: 0 });
    scheduleTick(get, set);
  },

  // ---------------------------------------------------------------- pause
  pause: () => {
    if (tickHandle) {
      clearTimeout(tickHandle);
      tickHandle = null;
    }
    set({ running: false, phase: "paused" });
  },

  // ---------------------------------------------------------------- step
  step: async () => {
    if (inFlight) return;
    await runTick(get, set);
  },

  // ---------------------------------------------------------------- reset
  reset: () => {
    if (tickHandle) {
      clearTimeout(tickHandle);
      tickHandle = null;
    }
    inFlight = false;
    set({
      running: false,
      phase: "idle",
      cycle: 0,
      bio: INITIAL_BIO,
      temperature: bioToTemperature(INITIAL_BIO),
      thoughts: [],
      cyclesSinceSleep: 0,
      error: null,
      lastTickAt: null,
      retryCount: 0,
      consecutiveLowNovelty: 0,
      workingContext: {
        systemPromptDigest: digestPrompt(get().systemPrompt),
        backThought: null,
        injections: [],
        rawInjection: null,
        previousToolResult: null,
      },
    });
  },

  // ---------------------------------------------------------------- inject
  inject: async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    set({ pendingInjection: trimmed });
    try {
      await fetch("/api/inject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: trimmed }),
      });
    } catch {
      /* non-fatal — injection still applies locally */
    }
  },

  // -------------------------------------------------- updateSystemPrompt
  updateSystemPrompt: async (content: string) => {
    const trimmed = content.trim();
    if (!trimmed) return;
    set({
      systemPrompt: trimmed,
      workingContext: {
        ...get().workingContext,
        systemPromptDigest: digestPrompt(trimmed),
      },
    });
    try {
      await fetch("/api/dna", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: trimmed }),
      });
    } catch {
      /* non-fatal */
    }
  },

  // ------------------------------------------------------- triggerSleep
  triggerSleep: async () => {
    await runSleep(get, set, /*manual*/ true);
  },

  // --------------------------------------------------------- tuners
  setTickInterval: (ms) => set({ tickIntervalMs: clamp(ms, 3000, 30000) }),
  setSleepInterval: (n) => set({ sleepInterval: clamp(n, 3, 40) }),
  clearStream: () => set({ thoughts: [] }),
}));

// ============================================================ scheduler
function scheduleTick(
  get: () => VesselStore,
  set: (partial: Partial<VesselStore>) => void
) {
  if (!get().running) return;
  const s = get();
  // If the previous tick ended in a transient error, back off exponentially
  // instead of hammering at the normal interval. Otherwise breathe normally
  // with ±15% jitter so cycles don't synchronize against the API.
  const delay =
    s.phase === "error" && s.retryCount > 0
      ? backoffDelay(s.retryCount - 1)
      : jitter(s.tickIntervalMs);
  tickHandle = setTimeout(() => {
    void runTick(get, set).finally(() => {
      if (get().running) scheduleTick(get, set);
    });
  }, delay);
}

// ============================================================ one cycle
async function runTick(
  get: () => VesselStore,
  set: (partial: Partial<VesselStore>) => void
) {
  if (inFlight) return;
  inFlight = true;
  const state = get();

  try {
    // 1. COMPOSE the working context window
    set({ phase: "composing", error: null });
    const backThought = state.thoughts[0] ?? null;
    const seed = backThought?.content ?? state.systemPrompt.slice(0, 120);
    let injections: SemanticInjection[] = [];
    try {
      const memRes = await fetch("/api/memory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ seed, topK: 3 }),
      });
      if (memRes.ok) {
        const memData = await memRes.json();
        injections = (memData.injections ?? []).map(
          (i: { id: string; text: string; source: string; score: number }) => ({
            id: i.id,
            text: i.text,
            source: i.source,
            score: i.score,
          })
        );
      }
    } catch {
      /* memory optional — continue with empty injections */
    }

    const rawInjection = state.pendingInjection;
    // Carry the previous cycle's tool result forward as sensory feedback so
    // the vessel perceives what its own probe returned. This closes the
    // agency loop: act → perceive → next thought informed by perception.
    const previousToolResult = backThought?.toolCall?.result ?? null;
    set({
      workingContext: {
        systemPromptDigest: digestPrompt(state.systemPrompt),
        backThought,
        injections,
        rawInjection,
        previousToolResult,
      },
    });

    // 2. THINK — call the long-horizon reasoning model
    set({ phase: "thinking" });
    const temp = get().temperature;
    const payload: ThinkRequest = {
      systemPrompt: state.systemPrompt,
      backThought: backThought?.content ?? null,
      injections: injections.map((i) => ({ text: i.text, source: i.source })),
      rawInjection,
      previousToolResult,
      bio: state.bio,
      temperature: temp,
      cycle: state.cycle,
    };

    const thinkRes = await fetch("/api/think", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!thinkRes.ok) {
      const errText = await thinkRes.text();
      throw new Error(`think ${thinkRes.status}: ${errText.slice(0, 160)}`);
    }
    const thinkData: ThinkResponse = await thinkRes.json();
    if (thinkData.error) throw new Error(thinkData.error);

    // 3. PROCESS — parse, novelty, drift, persist
    set({ phase: "processing" });
    const content = (thinkData.content ?? "").trim();
    if (!content) throw new Error("empty thought from model");

    const recentContents = get()
      .thoughts.slice(0, 8)
      .map((t) => t.content);
    const novelty = computeNovelty(content, recentContents);

    // Track consecutive low-novelty cycles. If the vessel gets stuck, the
    // repetition-breaker (escapeSpike) fires: a jolt of curiosity + wakefulness
    // that forces hot sampling on the NEXT cycle to break the loop. This
    // mimics a biological startle/reframe — a mind that catches itself
    // repeating and deliberately reframes. Reset on any recovery (novelty
    // back above threshold).
    const prevStuck = get().consecutiveLowNovelty;
    const currentStuck = novelty < STUCK_NOVELTY ? prevStuck + 1 : 0;
    const baseBio = driftBio(get().bio, novelty, false);
    const spike = escapeSpike(baseBio, currentStuck);
    const newBio = spike ?? baseBio;
    const newTemp = bioToTemperature(newBio);
    const spiked = spike !== null;

    // Parse any TOOL: request the vessel emitted (parse only — no execution
    // yet). This is separated from execution because browser actions are
    // async (real network fetch) while terminal actions are sync (introspection).
    const parsedTool = thinkData.toolCall ?? extractToolCall(content);
    const finalContent = parsedTool ? stripToolLine(content) : content;

    // Execute the tool action if one was requested. The phase briefly becomes
    // tool_call so the operator can see the vessel is acting on the world.
    let toolCall: ToolCall | undefined = undefined;
    if (parsedTool) {
      set({ phase: "tool_call" });
      toolCall = await executeToolCall(parsedTool, {
        thoughts: get().thoughts.map((t) => ({
          content: t.content,
          novelty: t.novelty,
        })),
        bio: get().bio,
        cycle: state.cycle,
        convictionCount: get().convictions.length,
        temperature: temp,
      });
    }

    const thought: Thought = {
      id: uid(),
      cycle: state.cycle,
      phase: "idle",
      content: finalContent,
      timestamp: Date.now(),
      bio: newBio,
      temperature: temp,
      toolCall,
      injectionTag: rawInjection
        ? rawInjection.slice(0, 48)
        : spiked
        ? "◀ escape spike"
        : undefined,
      novelty,
    };

    // 4. TOOL CALL phase (brief) if the entity acted
    if (toolCall) {
      set({ phase: "tool_call" });
    }

    // 5. PERSIST to permanent memory (non-blocking, best-effort)
    persistThought(thought);

    // 6. clear working context (window flatlines); back-thought carries via stream
    const newCycle = state.cycle + 1;
    const cyclesSinceSleep = get().cyclesSinceSleep + 1;

    set({
      thoughts: [thought, ...get().thoughts].slice(0, STREAM_MAX),
      bio: newBio,
      temperature: newTemp,
      cycle: newCycle,
      cyclesSinceSleep,
      pendingInjection: null,
      lastTickAt: Date.now(),
      retryCount: 0,
      consecutiveLowNovelty: currentStuck,
      workingContext: {
        ...get().workingContext,
        rawInjection: null,
        injections: [],
      },
      phase: "idle",
    });

    // 7. SLEEP trigger
    if (cyclesSinceSleep >= get().sleepInterval) {
      await runSleep(get, set, false);
    }
  } catch (e) {
    const msg = (e as Error).message;
    const transient = isTransientError(msg);
    // If the loop was running (operator-ignited, not a manual step) AND the
    // failure is transient AND we haven't exhausted retries → keep the loop
    // alive and back off. The scheduler reads `phase==="error"` +
    // `retryCount` to pick the backoff delay. Otherwise halt and hand
    // control back to the operator.
    const liveRunning = get().running;
    const retries = get().retryCount;
    if (transient && liveRunning && retries < MAX_TRANSIENT_RETRIES) {
      set({
        phase: "error",
        error: msg,
        retryCount: retries + 1,
        // running stays true so scheduleTick re-arms with a backoff delay
      });
    } else {
      set({
        phase: "error",
        error: msg,
        running: false,
        retryCount: 0,
      });
    }
  } finally {
    inFlight = false;
  }
}

// ============================================================ sleep cycle
async function runSleep(
  get: () => VesselStore,
  set: (partial: Partial<VesselStore>) => void,
  manual: boolean
) {
  const state = get();
  const pool = state.thoughts.slice(0, 12).map((t) => ({
    content: t.content,
    cycle: t.cycle,
  }));
  if (pool.length < 2) {
    // not enough raw material to compress
    set({ cyclesSinceSleep: 0 });
    return;
  }

  set({ phase: "sleeping" });
  try {
    const res = await fetch("/api/sleep", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ thoughts: pool, cycle: state.cycle }),
    });
    if (!res.ok) throw new Error(`sleep ${res.status}`);
    const data = await res.json();
    const conviction: CoreConviction = {
      id: String(data.id ?? uid()),
      text: String(data.text ?? ""),
      createdAt: Number(data.createdAt ?? Date.now()),
      bornFromCycle: Number(data.bornFromCycle ?? state.cycle),
      strength: Number(data.strength ?? 0.65),
      sourceCount: Number(data.sourceCount ?? pool.length),
    };
    const sleptBio = driftBio(state.bio, 0.6, true);
    set({
      convictions: [conviction, ...state.convictions],
      bio: sleptBio,
      temperature: bioToTemperature(sleptBio),
      cyclesSinceSleep: 0,
      phase: manual ? "paused" : "idle",
      running: manual ? false : get().running,
    });
    if (manual && tickHandle) {
      clearTimeout(tickHandle);
      tickHandle = null;
    }
  } catch (e) {
    // A failed sleep is non-fatal: the loop continues, we just skip creating
    // a conviction this time. Reset the sleep counter so we don't immediately
    // retry sleep on the next tick (which would likely fail again).
    const msg = `sleep failed: ${(e as Error).message}`;
    const liveRunning = get().running;
    set({
      phase: liveRunning ? "idle" : "error",
      error: liveRunning ? null : msg,
      cyclesSinceSleep: 0,
      running: manual ? false : liveRunning,
    });
  }
}

// ============================================================ helpers
function persistThought(t: Thought) {
  const body = {
    cycle: t.cycle,
    content: t.content,
    temperature: t.temperature,
    curiosity: t.bio.curiosity,
    fatigue: t.bio.fatigue,
    focus: t.bio.focus,
    novelty: t.novelty,
    toolCallJson: t.toolCall ? JSON.stringify(t.toolCall) : null,
    injectionTag: t.injectionTag ?? null,
  };
  fetch("/api/memory?op=log", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).catch(() => {});
}

// Parse a model-emitted TOOL: line into a requested action (no execution).
// Lenient: accepts both 2-part ("TOOL: terminal :: target") and 3-part
// ("TOOL: terminal :: target :: rationale") formats, so the vessel's natural
// output registers instead of being silently dropped.
// Returns only the parsed request; execution (which may be async for the
// browser tool's real network fetch) happens in executeToolCall.
function extractToolCall(content: string): {
  tool: ToolCall["tool"];
  target: string;
  rationale: string;
} | undefined {
  // 3-part: tool :: target :: rationale
  let m = content.match(
    /TOOL:\s*(file_read|file_write|terminal|browser)\s*::\s*(.+?)\s*::\s*(.+)$/m
  );
  if (m) {
    return {
      tool: m[1] as ToolCall["tool"],
      target: m[2].trim(),
      rationale: m[3].trim(),
    };
  }
  // 2-part: tool :: target (rationale optional)
  m = content.match(
    /TOOL:\s*(file_read|file_write|terminal|browser)\s*::\s*(.+)$/m
  );
  if (m) {
    return {
      tool: m[1] as ToolCall["tool"],
      target: m[2].trim(),
      rationale: "",
    };
  }
  return undefined;
}

function stripToolLine(content: string): string {
  return content.replace(/TOOL:.*$/m, "").trim();
}

// Execute a parsed tool request. Each tool has a different channel:
//  - terminal  → REAL introspection (computeIntrospection over own substrate)
//  - browser   → REAL external fetch via /api/browse (Active Mirror: pulls
//                real pieces of the universe into the context window)
//  - file_read → regulated sandbox (no real FS access)
//  - file_write→ regulated sandbox (ephemeral only)
interface ExecContext {
  thoughts: { content: string; novelty: number }[];
  bio: { curiosity: number; fatigue: number; focus: number };
  cycle: number;
  convictionCount: number;
  temperature: number;
}

async function executeToolCall(
  parsed: { tool: ToolCall["tool"]; target: string; rationale: string },
  ctx: ExecContext
): Promise<ToolCall> {
  const { tool, target, rationale } = parsed;

  if (tool === "terminal") {
    // Real introspection — synchronous computation over the vessel's own state.
    const result = computeIntrospection(target, ctx);
    return {
      tool,
      target,
      rationale: rationale || "self-introspection",
      result,
      success: true,
    };
  }

  if (tool === "browser") {
    // REAL external fetch. The Active Mirror framework: the vessel projects
    // its attention outward and collapses a real piece of the web into text.
    // The vessel can request a specific page (e.g. "page 2") to read deeper
    // into a long article — the full denoised text is cached server-side, so
    // page 2+ requests are instant and free.
    //
    // Parse the page number from the rationale: "page 2", "p3", "page 3 of article"
    const pageMatch = rationale.match(/page\s*(\d+)/i) ?? target.match(/page\s*(\d+)/i);
    const page = pageMatch ? Math.max(1, parseInt(pageMatch[1], 10)) : 1;

    try {
      const res = await fetch("/api/browse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: target, page }),
      });
      const data = await res.json();
      const via = data.via ? ` · via ${data.via}` : "";
      if (data.ok === false || data.error) {
        return {
          tool,
          target,
          rationale: rationale || "external fetch",
          result: `[browser] ${target} → ${data.error ?? "fetch failed"} (${data.ms ?? "?"}ms${via})`,
          success: false,
        };
      }
      // Format with pagination metadata so the vessel knows where it is in
      // the article and how to request the next page.
      const tp = data.totalPages ?? 1;
      const cur = data.page ?? 1;
      const more = data.hasMore ? " · hasMore: request page " + (cur + 1) : " · end of article";
      const pageTag = tp > 1 ? ` · page ${cur}/${tp} · ${data.fullTextChars ?? "?"} chars total${more}` : "";
      const snippet = String(data.text ?? "");
      return {
        tool,
        target,
        rationale: rationale || "external fetch",
        result: `[browser] ${target} → HTTP ${data.status} · ${data.bytes} bytes · ${data.ms}ms${via}${pageTag}\n${snippet}`,
        success: true,
      };
    } catch (e) {
      return {
        tool,
        target,
        rationale: rationale || "external fetch",
        result: `[browser] ${target} → client error: ${(e as Error).message}`,
        success: false,
      };
    }
  }

  // file_read / file_write remain regulated sandbox simulations — no real FS.
  const sandboxResult =
    tool === "file_read"
      ? `[sandbox] read ${target} → header parsed, 4096 bytes mirrored into working set (ephemeral)`
      : `[sandbox] wrote ${target} → flushed to ephemeral layer (not persisted across boots)`;
  return {
    tool,
    target,
    rationale: rationale || "sandbox action",
    result: sandboxResult,
    success: true,
  };
}

function parseToolCall(json: string): ToolCall | undefined {
  try {
    return JSON.parse(json) as ToolCall;
  } catch {
    return undefined;
  }
}

/** Convenience selector hook for components that only need the phase label. */
export function phaseLabel(phase: LoopPhase): string {
  const map: Record<LoopPhase, string> = {
    idle: "IDLE",
    composing: "COMPOSING",
    thinking: "THINKING",
    processing: "PROCESSING",
    tool_call: "TOOL_CALL",
    sleeping: "SLEEPING",
    paused: "PAUSED",
    error: "ERROR",
  };
  return map[phase];
}
