// vessel_observer — server-side LLM helper.
// z-ai-web-dev-sdk MUST stay backend-only; this module is imported solely by
// API route handlers.
//
// Includes retry with exponential backoff for transient failures (429 / 5xx /
// network) so brief rate-limit blips are absorbed server-side before the
// client loop ever sees an error.

import ZAI from "z-ai-web-dev-sdk";

let zaiPromise: Promise<ZAI> | null = null;

export async function getZAI(): Promise<ZAI> {
  if (!zaiPromise) {
    zaiPromise = ZAI.create();
  }
  return zaiPromise;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Is an error message likely transient (worth retrying)? */
function isTransient(msg: string): boolean {
  const m = msg.toLowerCase();
  return (
    m.includes("429") ||
    m.includes("too many requests") ||
    m.includes("rate limit") ||
    m.includes("502") ||
    m.includes("503") ||
    m.includes("504") ||
    m.includes("service unavailable") ||
    m.includes("bad gateway") ||
    m.includes("gateway timeout") ||
    m.includes("overloaded") ||
    m.includes("network") ||
    m.includes("econnreset") ||
    m.includes("etimedout") ||
    m.includes("aborted") ||
    m.includes("socket")
  );
}

/**
 * A single non-streaming chat completion with built-in retry/backoff.
 * Retries up to 3 times on transient failures (2s → 4s → 8s + jitter).
 * Returns the message content. Throws on non-transient errors or after
 * exhausting retries.
 */
export async function complete(
  systemPrompt: string,
  userMessage: string
): Promise<string> {
  const maxAttempts = 3;
  let lastErr: unknown = null;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const zai = await getZAI();
      const completion = await zai.chat.completions.create({
        messages: [
          { role: "assistant", content: systemPrompt },
          { role: "user", content: userMessage },
        ],
        thinking: { type: "disabled" },
      });
      const content = completion.choices[0]?.message?.content ?? "";
      if (!content) throw new Error("model returned empty content");
      return content;
    } catch (e) {
      lastErr = e;
      const msg = e instanceof Error ? e.message : String(e);
      if (attempt < maxAttempts - 1 && isTransient(msg)) {
        // backoff: 2s, 4s + up to 1s jitter
        const delay = 2000 * Math.pow(2, attempt) + Math.random() * 1000;
        await sleep(delay);
        continue;
      }
      break; // non-transient, or final attempt
    }
  }
  throw lastErr instanceof Error
    ? lastErr
    : new Error("unknown completion failure");
}
