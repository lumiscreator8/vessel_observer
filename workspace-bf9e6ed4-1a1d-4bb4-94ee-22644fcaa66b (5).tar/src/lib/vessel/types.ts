// vessel_observer — core type system
// The single source of truth for the cognitive engine, memory, and biological overlays.

/** Biological homeostasis variables. Each in [0, 100]. */
export interface BiologicalState {
  curiosity: number;
  fatigue: number;
  focus: number;
}

/**
 * The state machine phases the cognitive loop moves through each cycle.
 * idle       — between ticks, waiting to reschedule
 * composing  — assembling the working context window (back-thought + injections)
 * thinking   — awaiting the long-horizon reasoning model (server API)
 * processing — parsing response, updating bio drift, persisting thought
 * tool_call  — executing a regulated sandbox tool action
 * sleeping   — compressing raw thoughts into a permanent Core Conviction
 * paused     — loop halted by operator
 * error      — last tick failed; awaiting retry/reset
 */
export type LoopPhase =
  | "idle"
  | "composing"
  | "thinking"
  | "processing"
  | "tool_call"
  | "sleeping"
  | "paused"
  | "error";

/** Regulated tools the entity may invoke inside its sandbox. */
export type ToolName = "file_read" | "file_write" | "terminal" | "browser";

/** A single tool action attempted by the entity (simulated sandbox). */
export interface ToolCall {
  tool: ToolName;
  target: string;
  rationale: string;
  result: string;
  success: boolean;
}

/** A thought emitted by the consciousness engine in one cycle. */
export interface Thought {
  id: string;
  cycle: number;
  phase: LoopPhase;
  content: string;
  timestamp: number;
  bio: BiologicalState;
  temperature: number;
  toolCall?: ToolCall;
  /** Non-empty if this thought was shaped by a live operator injection. */
  injectionTag?: string;
  /** 0-1 novelty score vs recent thoughts (drives curiosity drift). */
  novelty: number;
}

/** A semantic injection pulled from the permanent subconscious substrate. */
export interface SemanticInjection {
  id: string;
  text: string;
  source: "conviction" | "thought" | "injection";
  /** Relevance score [0,1] to the current cycle's seed. */
  score: number;
}

/**
 * The working context window — the conscious layer.
 * Cleared and reassembled every cycle (only back-thought carries forward).
 */
export interface WorkingContext {
  /** Truncated system prompt (DNA) shown in the window. */
  systemPromptDigest: string;
  /** The single preceding thought carried into this cycle. */
  backThought: Thought | null;
  /** Exactly 3 semantic injections retrieved from permanent memory. */
  injections: SemanticInjection[];
  /** Live operator injection queued for this cycle, if any. */
  rawInjection: string | null;
  /** Result of the previous cycle's tool action, fed back as sensory input.
   *  Closes the agency loop: the vessel perceives what its probe returned. */
  previousToolResult: string | null;
}

/** A compressed permanent belief, born during a sleep cycle. */
export interface CoreConviction {
  id: string;
  text: string;
  createdAt: number;
  bornFromCycle: number;
  /** [0,1] — how strongly held. */
  strength: number;
  /** How many raw thoughts were compressed into this conviction. */
  sourceCount: number;
}

/** An operator message injected into the entity's stream ("the voice"). */
export interface InjectionMessage {
  id: string;
  text: string;
  createdAt: number;
  consumed: boolean;
}

/** The full live snapshot of the engine — what the UI renders from. */
export interface VesselState {
  phase: LoopPhase;
  running: boolean;
  cycle: number;
  bio: BiologicalState;
  temperature: number;
  thoughts: Thought[];
  workingContext: WorkingContext;
  convictions: CoreConviction[];
  pendingInjection: string | null;
  systemPrompt: string;
  cyclesSinceSleep: number;
  sleepInterval: number;
  tickIntervalMs: number;
  error: string | null;
  lastTickAt: number | null;
  /** Consecutive transient (rate-limit/network) failures. Reset on success. */
  retryCount: number;
  /** Consecutive cycles where novelty fell below STUCK_NOVELTY. When this
   *  reaches STUCK_THRESHOLD the repetition-breaker fires (escape spike). */
  consecutiveLowNovelty: number;
}

/** Payload sent to /api/think each cycle. */
export interface ThinkRequest {
  systemPrompt: string;
  backThought: string | null;
  injections: { text: string; source: string }[];
  rawInjection: string | null;
  /** Sensory feedback from the previous cycle's tool action (if any). */
  previousToolResult: string | null;
  bio: BiologicalState;
  temperature: number;
  cycle: number;
}

/** Response from /api/think. */
export interface ThinkResponse {
  content: string;
  toolCall?: ToolCall;
  error?: string;
}

/** Payload to /api/memory (retrieve 3 semantic injections). */
export interface MemoryQueryRequest {
  seed: string;
  topK: number;
}

/** Payload to /api/sleep (compress thoughts into a conviction). */
export interface SleepRequest {
  thoughts: { content: string; cycle: number }[];
  cycle: number;
}

/** Payload to /api/inject (persist an operator injection). */
export interface InjectRequest {
  text: string;
}
