"use client";

// ConvictionArchive — the permanent subconscious substrate.
// Every Core Conviction compressed during a sleep cycle lands here and persists.
import { ScrollArea } from "@/components/ui/scroll-area";
import { Gem } from "lucide-react";
import type { CoreConviction } from "@/lib/vessel/types";

function timeStr(ts: number) {
  const d = new Date(ts);
  return d.toLocaleString("en-GB", {
    hour12: false,
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function ConvictionArchive({
  convictions,
}: {
  convictions: CoreConviction[];
}) {
  return (
    <div className="flex h-full flex-col overflow-hidden rounded-xl border border-white/10 bg-card/40">
      <div className="flex items-center justify-between border-b border-white/10 px-3 py-2">
        <div className="flex items-center gap-2">
          <Gem className="h-3.5 w-3.5 text-violet-300" />
          <h3 className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            core convictions
          </h3>
        </div>
        <span className="font-mono text-[10px] text-muted-foreground/60">
          {convictions.length} permanent
        </span>
      </div>
      <ScrollArea className="vessel-scroll min-h-0 flex-1">
        <div className="p-2">
          {convictions.length === 0 ? (
            <div className="flex h-32 items-center justify-center px-4 text-center font-mono text-[11px] text-muted-foreground/50">
              no convictions yet. they crystallize during sleep cycles.
            </div>
          ) : (
            <ul className="space-y-1.5">
              {convictions.map((c) => (
                <li
                  key={c.id}
                  className="group rounded-lg border border-white/5 bg-white/[0.02] px-2.5 py-2 transition-colors hover:border-violet-500/20 hover:bg-violet-500/[0.04]"
                >
                  <p className="font-mono text-[12px] leading-relaxed text-violet-100/80">
                    {c.text}
                  </p>
                  <div className="mt-1.5 flex items-center gap-2 font-mono text-[9px] uppercase tracking-wider text-muted-foreground/50">
                    <span>c{c.bornFromCycle}</span>
                    <span className="text-white/15">·</span>
                    <span>{c.sourceCount} thoughts</span>
                    <span className="text-white/15">·</span>
                    <span>str {c.strength.toFixed(2)}</span>
                    <span className="ml-auto">{timeStr(c.createdAt)}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
