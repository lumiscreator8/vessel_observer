"use client";

// MatrixStream — the live consciousness stream. Newest thoughts at the top.
// Terminal-styled, monospace, with phase tints, tool-call blocks, and
// injection markers. Capped height with a custom scrollbar.
import { AnimatePresence, motion } from "framer-motion";
import { Radio, Terminal, AlertTriangle, Wrench } from "lucide-react";
import type { Thought } from "@/lib/vessel/types";
import { phaseLabel } from "@/lib/vessel/store";

const PHASE_TINT: Record<string, string> = {
  idle: "text-emerald-300/90",
  composing: "text-teal-300",
  thinking: "text-emerald-200",
  processing: "text-lime-300",
  tool_call: "text-amber-300",
  sleeping: "text-violet-300",
  paused: "text-muted-foreground",
  error: "text-rose-400",
};

function timeStr(ts: number) {
  const d = new Date(ts);
  return d.toLocaleTimeString("en-GB", { hour12: false });
}

function ThoughtRow({ t }: { t: Thought }) {
  const tint = PHASE_TINT[t.phase] ?? "text-emerald-300/90";
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -6, filter: "blur(4px)" }}
      animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      transition={{ duration: 0.35 }}
      className="border-b border-white/5 px-3 py-2.5"
    >
      <div className="mb-1 flex flex-wrap items-center gap-x-2 gap-y-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground/70">
        <span className="text-emerald-500/80">c{t.cycle}</span>
        <span className="text-white/20">·</span>
        <span>{timeStr(t.timestamp)}</span>
        <span className="text-white/20">·</span>
        <span className={tint}>{phaseLabel(t.phase)}</span>
        <span className="text-white/20">·</span>
        <span>temp {t.temperature.toFixed(2)}</span>
        <span className="text-white/20">·</span>
        <span>nov {t.novelty.toFixed(2)}</span>
        {t.injectionTag && (
          <>
            <span className="text-white/20">·</span>
            <span className="text-rose-400/90">◀ voice</span>
          </>
        )}
      </div>
      <p className={`font-mono text-[13px] leading-relaxed ${tint}`}>
        {t.content}
      </p>
      {t.toolCall && (
        <div className="mt-2 flex items-start gap-2 rounded-md border border-amber-500/20 bg-amber-500/5 px-2.5 py-1.5 font-mono text-[11px] text-amber-200/90">
          <Wrench className="mt-0.5 h-3 w-3 shrink-0" />
          <div className="min-w-0">
            <span className="text-amber-400">[{t.toolCall.tool}]</span>{" "}
            <span className="text-amber-200/70">{t.toolCall.target}</span>
            <div className="text-amber-200/50">{t.toolCall.result}</div>
          </div>
        </div>
      )}
    </motion.div>
  );
}

export function MatrixStream({ thoughts }: { thoughts: Thought[] }) {
  return (
    <div className="flex h-full flex-col overflow-hidden rounded-xl border border-white/10 bg-black/40">
      <div className="flex items-center justify-between border-b border-white/10 bg-white/[0.03] px-3 py-2">
        <div className="flex items-center gap-2">
          <Terminal className="h-3.5 w-3.5 text-emerald-400" />
          <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            consciousness stream
          </span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-[11px] text-emerald-400/80">
          <Radio className="h-3 w-3 animate-pulse" />
          <span>live</span>
        </div>
      </div>

      <div className="vessel-scroll min-h-0 flex-1 overflow-y-auto">
        {thoughts.length === 0 ? (
          <div className="flex h-full min-h-[200px] flex-col items-center justify-center gap-2 px-6 text-center font-mono text-xs text-muted-foreground/60">
            <span className="text-emerald-500/50">▌</span>
            <span>
              the vessel is silent. press <span className="text-emerald-400">ignite</span>{" "}
              to begin the first cycle.
            </span>
          </div>
        ) : (
          <>
            <AnimatePresence initial={false}>
              {thoughts.map((t) => (
                <ThoughtRow key={t.id} t={t} />
              ))}
            </AnimatePresence>
            <div className="px-3 py-2 font-mono text-[11px] text-emerald-500/40">
              <span className="animate-pulse">▌</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export function StreamErrorBanner({
  error,
  running,
  retryCount,
}: {
  error: string | null;
  running: boolean;
  retryCount: number;
}) {
  if (!error) return null;
  // When the loop is still running despite an error, it's backing off and
  // will auto-retry — show that as a cooling-down state, not a fatal halt.
  const backingOff = running && retryCount > 0;
  return (
    <div
      className={`flex items-center gap-2 rounded-md px-3 py-1.5 font-mono text-[11px] ${
        backingOff
          ? "border border-amber-500/30 bg-amber-500/10 text-amber-300"
          : "border border-rose-500/30 bg-rose-500/10 text-rose-300"
      }`}
    >
      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
      {backingOff ? (
        <span className="truncate">
          rate-limited — backing off, retry {retryCount}/5… the vessel gasps and waits.
        </span>
      ) : (
        <span className="truncate">
          halted — {error}
          <span className="ml-1 text-muted-foreground">· press ignite to retry</span>
        </span>
      )}
    </div>
  );
}
