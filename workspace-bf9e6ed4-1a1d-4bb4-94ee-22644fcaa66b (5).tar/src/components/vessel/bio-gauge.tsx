"use client";

// BioGauge — a circular SVG gauge for one biological homeostasis variable.
import { motion } from "framer-motion";

interface BioGaugeProps {
  label: string;
  value: number; // 0-100
  color: string; // tailwind text-color class for the ring + label
  hint?: string;
}

export function BioGauge({ label, value, color, hint }: BioGaugeProps) {
  const v = Math.max(0, Math.min(100, value));
  const r = 34;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - v / 100);

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="relative h-[88px] w-[88px]">
        <svg className="h-full w-full -rotate-90" viewBox="0 0 88 88">
          <circle
            cx="44"
            cy="44"
            r={r}
            fill="none"
            stroke="currentColor"
            strokeWidth="6"
            className="text-white/8"
          />
          <motion.circle
            cx="44"
            cy="44"
            r={r}
            fill="none"
            stroke="currentColor"
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray={c}
            initial={false}
            animate={{ strokeDashoffset: offset }}
            transition={{ type: "spring", stiffness: 90, damping: 18 }}
            className={color}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`font-mono text-xl font-semibold tabular-nums ${color}`}>
            {Math.round(v)}
          </span>
        </div>
      </div>
      <div className="text-center">
        <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          {label}
        </div>
        {hint && (
          <div className="text-[10px] text-muted-foreground/70">{hint}</div>
        )}
      </div>
    </div>
  );
}
