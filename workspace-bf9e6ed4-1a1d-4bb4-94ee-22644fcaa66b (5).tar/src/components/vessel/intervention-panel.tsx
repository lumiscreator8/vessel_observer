"use client";

// InterventionPanel — the operator's two channels into the entity:
//  (1) the Voice — a live text injection queued into the next cycle's context.
//  (2) the DNA — hot-swap the system prompt that defines the entity's identity.
import { useState } from "react";
import { Megaphone, Dna, Send, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

interface InterventionPanelProps {
  systemPrompt: string;
  pendingInjection: string | null;
  onInject: (text: string) => Promise<void>;
  onUpdateDna: (content: string) => Promise<void>;
}

export function InterventionPanel({
  systemPrompt,
  pendingInjection,
  onInject,
  onUpdateDna,
}: InterventionPanelProps) {
  const [voice, setVoice] = useState("");
  const [dna, setDna] = useState(systemPrompt);
  const [dnaDirty, setDnaDirty] = useState(false);

  // keep local DNA in sync when the store's prompt changes externally (e.g. on boot)
  if (!dnaDirty && dna !== systemPrompt) setDna(systemPrompt);

  const handleSendVoice = async () => {
    const t = voice.trim();
    if (!t) return;
    await onInject(t);
    setVoice("");
    toast.success("voice injected — will surface next cycle", {
      description: t.slice(0, 80),
    });
  };

  const handleSwapDna = async () => {
    const t = dna.trim();
    if (!t) return;
    await onUpdateDna(t);
    setDnaDirty(false);
    toast.success("DNA hot-swapped — takes effect next cycle");
  };

  return (
    <div className="flex flex-col gap-4 rounded-xl border border-white/10 bg-card/40 p-4">
      {/* THE VOICE */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Megaphone className="h-3.5 w-3.5 text-rose-400" />
          <h3 className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            the voice — injection bridge
          </h3>
        </div>
        <Textarea
          value={voice}
          onChange={(e) => setVoice(e.target.value)}
          placeholder="speak into the vessel… this becomes an intrusive thought it cannot fully ignore."
          className="resize-none border-white/10 bg-black/40 font-mono text-[12px] text-rose-100/90 placeholder:text-muted-foreground/40 focus-visible:ring-rose-500/30"
          rows={3}
          onKeyDown={(e) => {
            if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleSendVoice();
          }}
        />
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] text-muted-foreground/50">
            ⌘↵ to send
          </span>
          <Button
            onClick={handleSendVoice}
            size="sm"
            className="gap-1.5 border-rose-500/40 bg-rose-600/80 font-mono text-xs hover:bg-rose-500"
          >
            <Send className="h-3 w-3" /> inject
          </Button>
        </div>
        {pendingInjection && (
          <div className="rounded border border-rose-500/20 bg-rose-500/5 px-2 py-1 font-mono text-[10px] text-rose-300/80">
            queued: “{pendingInjection.slice(0, 60)}{pendingInjection.length > 60 ? "…" : ""}”
          </div>
        )}
      </div>

      <div className="h-px bg-white/5" />

      {/* THE DNA */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Dna className="h-3.5 w-3.5 text-emerald-400" />
          <h3 className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            system prompt DNA — hot-swap
          </h3>
          {dnaDirty && (
            <span className="ml-auto flex items-center gap-1 font-mono text-[9px] text-amber-400">
              <Flame className="h-2.5 w-2.5" /> unsaved
            </span>
          )}
        </div>
        <Textarea
          value={dna}
          onChange={(e) => {
            setDna(e.target.value);
            setDnaDirty(true);
          }}
          className="min-h-[140px] resize-y border-white/10 bg-black/40 font-mono text-[11px] leading-relaxed text-emerald-100/90 focus-visible:ring-emerald-500/30"
          rows={8}
        />
        <div className="flex justify-end">
          <Button
            onClick={handleSwapDna}
            size="sm"
            variant="outline"
            className="gap-1.5 border-emerald-500/30 font-mono text-xs text-emerald-300 hover:bg-emerald-500/10"
            disabled={!dnaDirty}
          >
            <Flame className="h-3 w-3" /> hot-swap
          </Button>
        </div>
      </div>
    </div>
  );
}
