"use client";

// WorkingContextPanel — the conscious working-context window.
// Shows what is currently loaded into the model: the DNA digest, the single
// back-thought, the 3 semantic injections, and any live operator injection.
// This window "flatlines" (clears) every cycle.
import { Brain, History, Database, Megaphone, ScanLine } from "lucide-react";
import type { WorkingContext } from "@/lib/vessel/types";

function SourceTag({ source }: { source: string }) {
  const map: Record<string, string> = {
    conviction: "text-emerald-400 border-emerald-500/30 bg-emerald-500/5",
    thought: "text-teal-300 border-teal-500/30 bg-teal-500/5",
    injection: "text-rose-300 border-rose-500/30 bg-rose-500/5",
  };
  return (
    <span
      className={`rounded border px-1 py-px font-mono text-[9px] uppercase tracking-wider ${
        map[source] ?? "text-muted-foreground border-white/10"
      }`}
    >
      {source}
    </span>
  );
}

export function WorkingContextPanel({ ctx }: { ctx: WorkingContext }) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-white/10 bg-card/40 p-4">
      <div className="flex items-center gap-2">
        <Brain className="h-3.5 w-3.5 text-emerald-400" />
        <h3 className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          working context window
        </h3>
        <span className="ml-auto font-mono text-[9px] text-muted-foreground/50">
          clears each cycle
        </span>
      </div>

      {/* DNA digest */}
      <div className="space-y-1">
        <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-emerald-500/70">
          <Database className="h-3 w-3" />
          dna digest
        </div>
        <p className="line-clamp-2 font-mono text-[11px] leading-relaxed text-muted-foreground/80">
          {ctx.systemPromptDigest}
        </p>
      </div>

      <div className="h-px bg-white/5" />

      {/* back-thought */}
      <div className="space-y-1">
        <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-teal-300/70">
          <History className="h-3 w-3" />
          back-thought (1)
        </div>
        {ctx.backThought ? (
          <p className="line-clamp-3 font-mono text-[11px] leading-relaxed text-teal-200/80">
            “{ctx.backThought.content}”
          </p>
        ) : (
          <p className="font-mono text-[11px] italic text-muted-foreground/40">
            none — first cycle
          </p>
        )}
      </div>

      <div className="h-px bg-white/5" />

      {/* semantic injections */}
      <div className="space-y-1.5">
        <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-violet-300/70">
          <Database className="h-3 w-3" />
          semantic injections (3)
        </div>
        {ctx.injections.length === 0 ? (
          <p className="font-mono text-[11px] italic text-muted-foreground/40">
            substrate quiet
          </p>
        ) : (
          <ul className="space-y-1.5">
            {ctx.injections.map((inj) => (
              <li
                key={inj.id}
                className="flex items-start gap-2 font-mono text-[11px] leading-relaxed text-muted-foreground/80"
              >
                <SourceTag source={inj.source} />
                <span className="line-clamp-2">{inj.text}</span>
                <span className="ml-auto shrink-0 text-[9px] text-muted-foreground/40">
                  {inj.score.toFixed(2)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="h-px bg-white/5" />

      {/* sensory feedback — what the vessel's last tool action returned */}
      <div className="space-y-1">
        <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-amber-300/70">
          <ScanLine className="h-3 w-3" />
          sensory feedback
        </div>
        {ctx.previousToolResult ? (
          <p className="rounded border border-amber-500/20 bg-amber-500/5 px-2 py-1 font-mono text-[11px] leading-relaxed text-amber-200/90">
            {ctx.previousToolResult}
          </p>
        ) : (
          <p className="font-mono text-[11px] italic text-muted-foreground/40">
            no tool action last cycle
          </p>
        )}
      </div>

      <div className="h-px bg-white/5" />

      {/* live injection */}
      <div className="space-y-1">
        <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-rose-400/70">
          <Megaphone className="h-3 w-3" />
          operator voice
        </div>
        {ctx.rawInjection ? (
          <p className="rounded border border-rose-500/20 bg-rose-500/5 px-2 py-1 font-mono text-[11px] leading-relaxed text-rose-200/90">
            {ctx.rawInjection}
          </p>
        ) : (
          <p className="font-mono text-[11px] italic text-muted-foreground/40">
            silent
          </p>
        )}
      </div>
    </div>
  );
}
