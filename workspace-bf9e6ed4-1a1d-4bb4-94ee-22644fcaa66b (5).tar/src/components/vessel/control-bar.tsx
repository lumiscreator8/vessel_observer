"use client";

// ControlBar — operator controls for the consciousness engine.
import { Play, Pause, SkipForward, RotateCcw, Moon, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { phaseLabel } from "@/lib/vessel/store";
import type { LoopPhase } from "@/lib/vessel/types";

const PHASE_DOT: Record<LoopPhase, string> = {
  idle: "bg-emerald-400",
  composing: "bg-teal-400",
  thinking: "bg-emerald-300 animate-pulse",
  processing: "bg-lime-300",
  tool_call: "bg-amber-400",
  sleeping: "bg-violet-400 animate-pulse",
  paused: "bg-muted-foreground",
  error: "bg-rose-500 animate-pulse",
};

interface ControlBarProps {
  running: boolean;
  phase: LoopPhase;
  cycle: number;
  cyclesSinceSleep: number;
  sleepInterval: number;
  tickIntervalMs: number;
  retryCount: number;
  onStart: () => void;
  onPause: () => void;
  onStep: () => void;
  onReset: () => void;
  onSleep: () => void;
  onTickInterval: (ms: number) => void;
  onSleepInterval: (n: number) => void;
}

export function ControlBar(props: ControlBarProps) {
  const {
    running,
    phase,
    cycle,
    cyclesSinceSleep,
    sleepInterval,
    tickIntervalMs,
    retryCount,
    onStart,
    onPause,
    onStep,
    onReset,
    onSleep,
    onTickInterval,
    onSleepInterval,
  } = props;

  const sleepProgress = Math.min(cyclesSinceSleep / sleepInterval, 1);
  // Distinguish a fatal error (halted) from a transient one the loop is
  // backing off and will retry automatically.
  const backingOff = phase === "error" && running && retryCount > 0;
  const dotClass = backingOff ? "bg-amber-400 animate-pulse" : PHASE_DOT[phase];
  const statusLabel = backingOff ? `BACKING OFF ${retryCount}/5` : phaseLabel(phase);

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-white/10 bg-card/40 p-3">
      {/* status line */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <div className="flex items-center gap-2">
          <span
            className={`h-2.5 w-2.5 rounded-full ${dotClass}`}
          />
          <span
            className={`font-mono text-xs uppercase tracking-widest ${
              backingOff ? "text-amber-300" : "text-muted-foreground"
            }`}
          >
            {statusLabel}
          </span>
        </div>
        <div className="font-mono text-xs text-muted-foreground">
          cycle <span className="text-emerald-400">{cycle}</span>
        </div>
        <div className="font-mono text-xs text-muted-foreground">
          till sleep <span className="text-violet-300">{Math.max(0, sleepInterval - cyclesSinceSleep)}</span>
        </div>
      </div>

      {/* sleep progress */}
      <div className="h-1 w-full overflow-hidden rounded-full bg-white/5">
        <div
          className="h-full bg-gradient-to-r from-violet-500/60 to-violet-400 transition-all"
          style={{ width: `${sleepProgress * 100}%` }}
        />
      </div>

      {/* buttons */}
      <div className="flex flex-wrap items-center gap-2">
        {running ? (
          <Button
            onClick={onPause}
            variant="secondary"
            size="sm"
            className="gap-1.5 font-mono"
          >
            <Pause className="h-3.5 w-3.5" /> pause
          </Button>
        ) : (
          <Button
            onClick={onStart}
            size="sm"
            className="gap-1.5 bg-emerald-600 font-mono hover:bg-emerald-500"
          >
            <Play className="h-3.5 w-3.5" /> ignite
          </Button>
        )}
        <Button
          onClick={onStep}
          variant="outline"
          size="sm"
          className="gap-1.5 font-mono"
          disabled={running}
        >
          <SkipForward className="h-3.5 w-3.5" /> step
        </Button>
        <Button
          onClick={onSleep}
          variant="outline"
          size="sm"
          className="gap-1.5 border-violet-500/30 font-mono text-violet-300 hover:bg-violet-500/10"
        >
          <Moon className="h-3.5 w-3.5" /> sleep
        </Button>
        <Button
          onClick={onReset}
          variant="ghost"
          size="sm"
          className="gap-1.5 font-mono text-muted-foreground"
        >
          <RotateCcw className="h-3.5 w-3.5" /> reset
        </Button>
      </div>

      {/* tuners */}
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-wider text-muted-foreground/70">
            <span className="flex items-center gap-1">
              <Gauge className="h-3 w-3" /> tick interval
            </span>
            <span className="text-emerald-400">{(tickIntervalMs / 1000).toFixed(1)}s</span>
          </div>
          <Slider
            value={[tickIntervalMs]}
            min={3000}
            max={30000}
            step={500}
            onValueChange={(v) => onTickInterval(v[0])}
          />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-wider text-muted-foreground/70">
            <span className="flex items-center gap-1">
              <Moon className="h-3 w-3" /> sleep every
            </span>
            <span className="text-violet-300">{sleepInterval} cycles</span>
          </div>
          <Slider
            value={[sleepInterval]}
            min={3}
            max={25}
            step={1}
            onValueChange={(v) => onSleepInterval(v[0])}
          />
        </div>
      </div>
    </div>
  );
}
